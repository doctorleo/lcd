#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/fb.h>
#include <sys/ioctl.h>

#include <sys/mman.h>

#define DEBUG

#define DEBUG_PROMPT "----debug print----"
#define debug_printF(str) \
	({printf("%s\t%s\t%s,%s,%d\n", DEBUG_PROMPT, (str), __FILE__, __func__, __LINE__) ;})

/*globale fb_buf for lcd*/
static unsigned char *fb_buf;
/*globale screen width and height for lcd
 * w : xres------ width 
 * h : yres------ height
 */
static int w,h;
/*global deepth of lcd*/
static int bpp;

int lcd_init(char *lcd_dev)
{
	if(lcd_dev == NULL)
	{
		debug_printF("invalid argument");
		/*a invalid argument*/
		return -EINVAL;
	}

	int fd = open(lcd_dev, O_RDWR);
	/*
	 * fd == -1 or fd < 0
	 */
	if(fd == -1)
	{
		debug_printF("open");
	}

	/*get the specific parameter of current device of frame buffer*/
	struct fb_var_screeninfo fb_info;
	if(ioctl(fd, FBIOGET_VSCREENINFO, &fb_info) < 0)
	{
		debug_printF("ioctl");
	}

	/*get the size of the buffer of a frame*/
	w = fb_info.xres;
	h = fb_info.yres;
	bpp = fb_info.bits_per_pixel;
	unsigned int frame_size = fb_info.xres * fb_info.yres * fb_info.bits_per_pixel / 8;

	/*memory map to use for user*/
	unsigned char *frame_buffer = mmap(0, frame_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	if(frame_buffer == NULL)/*MAP_FAILED == frame_buffer*/
	{
		debug_printF("mmap");
	}
	fb_buf = frame_buffer;

#ifdef DEBUG
	printf("%s\t%s, %d, %d, %dbpp, initialized ok!\n", DEBUG_PROMPT, "screen info : ", fb_info.xres, fb_info.yres, fb_info.bits_per_pixel);
#endif

	return fd;
}

int lcd_close(int fd)
{
	unsigned int frame_size = w * h * bpp / 8;
	if(munmap(fb_buf, frame_size) < 0)
	{
		debug_printF("munmap");
	}

#ifdef DEBUG
	printf("%s\t%s, %d, %d, %dbpp, closed ok!\n", DEBUG_PROMPT, "lcd close : ", w, h, bpp);
#endif
	return close(fd);
}

unsigned char *lcd_get_buffer(void)
{
	return fb_buf;
}

/*clear the lcd*/
void lcd_clear(unsigned char *buf)
{
	if(buf == NULL)
	{
		buf = fb_buf;
	}

	memset(buf, 0x0FF, w*h*bpp/8);

	return ;
}
