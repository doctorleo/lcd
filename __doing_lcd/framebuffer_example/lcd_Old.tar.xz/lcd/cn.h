#ifndef __CN_H__
#define __CN_H__

int display_cn_init(unsigned char *lcd_fb);
int display_cn_exit(unsigned char *lcd_fb);
void display_cn_chr_gb2312_16_x16(unsigned char *src, \
		int line, int column, unsigned int color);

void display_cn_str_gb2312_16_x16(unsigned char *src, \
		int line, int column, unsigned int color);

void display_cn_chr_gb2312_32_x32(unsigned char *src, \
		int line, int column, unsigned int color);

void display_cn_str_gb2312_32_x32(unsigned char *src, \
		int line, int column, unsigned int color);

#endif /* __CN_H__ */
