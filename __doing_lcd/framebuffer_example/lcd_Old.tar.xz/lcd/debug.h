#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdio.h>

#define debug(fp, fmt, arg...) ({ \
		fprintf(fp, fmt, ##arg); })

#define debug_error(fp, fmt, arg...) ({ \
		fprintf(fp, fmt, ##arg); \
		exit(0); })

#endif /* __DEBUG_H__ */
