//lcd.h
#ifndef _LCD_H_
#define _LCD_H_

/*interfaces for lcd frame buffer*/
/*
 * initialize the lcd
 * @fbx : device name of the frame bufer帧缓存设备名称
 * @return value : a local variable of file descriptor,返回打开设备的文件描述符
 *  return 0 if success, less than 0 if failed.
 */
int lcd_init(char *fdx);

/*close the lcd
 * @fd : the file descriptor of the open device of frame buffer
 * @return value : the same to system call int close(int fd)
 */
int lcd_close(int fd);

/*get the buffer*/
char *lcd_get_buffer(void);

/*clear the screen of lcd*/
void lcd_clear(unsigned char *buf);
#endif /*_LCD_H_*/

