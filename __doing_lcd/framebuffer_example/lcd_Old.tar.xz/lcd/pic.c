#include "lcd.h"

//#define PHYSICAL_WIDTH 320
//#define PHYSICAL_HEIGHT 240
#define PHYSICAL_WIDTH 480
#define PHYSICAL_HEIGHT 272

void show_pic(unsigned char *pic, int width, int height, int bpp)
{
	unsigned char *dest;
	unsigned char *src = pic;
	int col, line;

	dest = lcd_get_buffer();

	for(line=0; line<height; line++)
	{
		for(col=0;col<width; col++)
		{
#if 0
			*dest++ = *(src+1);
			*dest++ = *(src+2);
#else
			*dest++ = *(src+2);
			*dest++ = *(src+1);
#endif
			src+=2;
		}

		/** 480 X 272 */
		dest += 2 * (480-320);
	}

	return;
}

