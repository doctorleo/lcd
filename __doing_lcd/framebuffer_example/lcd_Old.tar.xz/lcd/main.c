//main.c
#include <stdio.h>
#include "lcd.h"
#define LCD_FB_NAME "/dev/fb0"

extern unsigned char *cn_ch;
extern unsigned char *cn_string;
unsigned char pic_pic[320*240*2];

int main()
{
	/*initialize the lcd fb*/
	int lcd_fd = lcd_init(LCD_FB_NAME);
	unsigned char *fb_buf =  lcd_get_buffer();
	
	lcd_clear(fb_buf);

	display_cn_init(NULL);

	display_cn_chr_gb2312_16_x16(cn_ch, 0, 0, 0x1f<<6);
	display_cn_chr_gb2312_16_x16(cn_ch, 30, 0, 0x1f<<6);
	display_cn_chr_gb2312_16_x16(cn_ch, 30, 30, 0x1f<<6);
	display_cn_str_gb2312_16_x16(cn_string, 60, 60, 0x1f<<6);

	display_cn_chr_gb2312_32_x32(cn_ch, 100, 0, 0x1f<<11);
	display_cn_str_gb2312_32_x32(cn_string, 140, 0, 0x1f<<6);

	display_cn_exit(NULL);

	//show_pic(pic_pic, 320, 240, 16);

	lcd_close(lcd_fd);
}


