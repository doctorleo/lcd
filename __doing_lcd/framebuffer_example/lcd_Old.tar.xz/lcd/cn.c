#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "debug.h"
#include "lcd.h"

#define GAP_LINE 20
//#define PHYSICAL_WIDTH 320
#define PHYSICAL_WIDTH 480
#define GAP_COLUMN 20

#define MAX_LINE_NUMBER 32
#define SECT_OFFSET_H  0xa0
#define SECT_OFFSET_W  0xa0
#define CHRS_PER_SECT  94

#define GB2312_16_x16_NRS 32
#define GB2312_16_x16_LINES 16
#define GB2312_16_x16_BYTES_PER_LINE 2
#define GB2312_16_x16_COLUMN_OFFSET 20
#define BITS_PER_BYTE 8

#define GB2312_32_x32_NRS 128
#define GB2312_32_x32_LINES 32 
#define GB2312_32_x32_BYTES_PER_LINE 4
#define GB2312_32_x32_COLUMN_OFFSET 40

#define HZK16X16 "hzk16"
unsigned char *codc_16x16 = NULL;

#define HZK32X32 "hzk32"
unsigned char *codc_32x32 = NULL;
unsigned char *fb = NULL;
unsigned short *line_x32[MAX_LINE_NUMBER];

int display_cn_init(unsigned char *lcd_fb)
{
	FILE *fp = NULL;
	long size = 0;
	int nr;

	fb = lcd_get_buffer();
	if(codc_16x16 == NULL)
	{
		fp = fopen(HZK16X16, "r");
		if(fp == NULL)
		{
			debug_error(stderr, "[%s, %d] fopen failed : %s\n", \
					__FILE__, __LINE__, strerror(errno));
		}

		if(fseek(fp, 0, SEEK_END))
		{
			debug_error(stderr, "[%s, %d] fseek failed.\n", __FILE__, __LINE__);
		}
		if( (size = ftell(fp)) == -1)
		{
			debug_error(stderr, "[%s, %d] %s\'s size = %ld.\n", \
					__FILE__, __LINE__, HZK16X16, size);
		}
		debug(stderr, "[%s, %d] %s\'s size = %ld, size/32 = %ld.\n", \
				__FILE__, __LINE__, HZK16X16, size, size/16/16*8);

		if( (codc_16x16 = malloc(size)) == NULL)
		{
			debug_error(stderr, "[%s, %d] malloc failed.\n", __FILE__, __LINE__);
		}

		if(fseek(fp, 0, SEEK_SET))
		{
			debug_error(stderr, "[%s, %d] fseek failed.\n", __FILE__, __LINE__);
		}

		nr = fread(codc_16x16, 16 * 16 / 8, size / 16 / 16 * 8, fp);
		if(nr != (size / 16 /16 * 8) )
		{
			debug_error(stderr, "[%s, %d] fread failed, nr = %d, should be %ld : %s\n", \
					__FILE__, __LINE__, nr, size / 16 / 16 * 8, strerror(errno));
		}

		fclose(fp);
	}

#if 1

	if(codc_32x32 == NULL)
	{
		fp = fopen(HZK32X32, "r");
		if(fp == NULL)
		{
			debug_error(stderr, "[%s, %d]open failed.\n", __FILE__, __LINE__);
		}

		if(fseek(fp, 0, SEEK_END))
		{
			debug_error(stderr, "[%s, %d] fseek failed.\n", __FILE__, __LINE__);
		}
		if( (size = ftell(fp)) == -1)
		{
			debug_error(stderr, "[%s, %d] %s\'s size = %ld.\n", \
					__FILE__, __LINE__, HZK32X32, size);
		}
		debug(stderr, "[%s, %d] %s\'s size = %ld, size/128 = %ld.\n", \
				__FILE__, __LINE__, HZK32X32, size, size/128);

		if( (codc_32x32 = malloc(size)) == NULL)
		{
			debug_error(stderr, "[%s, %d] malloc failed.\n", __FILE__, __LINE__);
		}

		if(fseek(fp, 0, SEEK_SET))
		{
			debug_error(stderr, "[%s, %d] fseek failed.\n", __FILE__, __LINE__);
		}

		nr = fread(codc_32x32, 32 * 32 / 8, size / 32 / 32 * 8, fp);
		if(nr != (size / 32 / 32 * 8) )
		{
			debug_error(stderr, "[%s, %d] fread failed, nr = %d, should be %ld.\n", \
					__FILE__, __LINE__, nr, size / 32 / 32 * 8);
		}

		fclose(fp);
	}

#endif

}

int display_cn_exit(unsigned char *lcd_fb)
{
	free(codc_16x16);
	free(codc_32x32);

	codc_16x16 = NULL;
	codc_32x32 = NULL;

	return 0;
}


void display_cn_chr_gb2312_16_x16(unsigned char *src, int line, int column, unsigned int color)
{
	unsigned int qh, wh;
	unsigned offset;
	unsigned short *fb;
	int i, j, k;
	//unsigned short *code;
	unsigned char *code;

	qh = src[0] - SECT_OFFSET_H - 1;
	wh = src[1] - SECT_OFFSET_W - 1;

	offset = (CHRS_PER_SECT * qh + wh) * GB2312_16_x16_NRS;

	fb = (unsigned short *)lcd_get_buffer();
#if 1
	fb += GAP_LINE * PHYSICAL_WIDTH + GAP_COLUMN;
#endif

	fb += line * PHYSICAL_WIDTH + column;

	for(i=0; i<GB2312_16_x16_LINES; i++)
	{
		line_x32[i] = fb + i * PHYSICAL_WIDTH;
#if 0
		for(j=0; j<320; j++)
		{
			*(line_x32[i]+j) = color;
		}
#endif
	}

	code = codc_16x16 + offset;

#if 0
	for(i=0; i<16; i++)
	{
		for(j=0; j<16; j++)
		{
			*(line_x32[i] + j) = color;
		}
	}
#else
	for(i=0; i<GB2312_16_x16_LINES; i++)
	{
		for(j=0; j<GB2312_16_x16_BYTES_PER_LINE; j++)
		{
			for(k=0; k<BITS_PER_BYTE; k++)
			{
				if(code[i*GB2312_16_x16_BYTES_PER_LINE + j] & (0x80 >> k) )
				{
					*(line_x32[i] + j * BITS_PER_BYTE + k) = color;
				}
			}
		}
	}

#endif

	return;
}

void display_cn_str_gb2312_16_x16(unsigned char *src, \
		int line, int column, unsigned int color)
{
	int nr = strlen(src);
	int i;

	for(i=0; i<nr/2; i++)
	{
		display_cn_chr_gb2312_16_x16(src+i*2, line, \
				column + i * GB2312_16_x16_COLUMN_OFFSET, color);
	}

	return;
}

void display_cn_chr_gb2312_32_x32(unsigned char *src, \
		int line, int column, unsigned int color)
{
	unsigned int qh, wh;
	unsigned offset;
	unsigned short *fb;
	int i, j, k;
	//unsigned short *code;
	unsigned char *code;

	qh = src[0] - SECT_OFFSET_H -1;
	wh = src[1] - SECT_OFFSET_W -1;

	offset = (CHRS_PER_SECT * qh + wh) * GB2312_32_x32_NRS;

	fb = (unsigned short *)lcd_get_buffer();
#if 1
	fb += GAP_LINE * PHYSICAL_WIDTH + GAP_COLUMN;
#endif

	fb += line *PHYSICAL_WIDTH + column;

	for(i=0; i<GB2312_32_x32_LINES; i++)
	{
		line_x32[i] = fb + i * PHYSICAL_WIDTH;
#if 0
		for(j=0; j<320; j++)
		{
			*(line_x32[i]+j) = color;
		}
#endif
	}

	code = codc_32x32 + offset;

#if 0
	for(i=0; i<16; i++)
	{
		for(j=0; j<16; j++)
		{
			*(line_x32[i] + j) = color;
		}
	}
#else
	for(i=0; i<GB2312_32_x32_LINES; i++)
	{
		for(j=0; j<GB2312_32_x32_BYTES_PER_LINE; j++)
		{
			for(k=0; k<BITS_PER_BYTE; k++)
			{
#if 1
				if(code[i*GB2312_32_x32_BYTES_PER_LINE + j] & (0x80 >> k) )
				{
					*(line_x32[i] + j * BITS_PER_BYTE + k) = color;
				}
#endif
				//*(line_x32[i] + j * 8 + k) = color;
			}
		}
	}

#endif

	return;
}


void display_cn_str_gb2312_32_x32(unsigned char *src, \
		int line, int column, unsigned int color)
{
	int nr = strlen(src);
	int i;

	for(i=0; i<nr/2; i++)
	{
		display_cn_chr_gb2312_32_x32(src+i*2, line, column + i * GB2312_32_x32_COLUMN_OFFSET, color);
	}

	return;
}
